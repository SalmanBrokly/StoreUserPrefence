//
//  ViewController.swift
//  NSUserSessionProject
//
//  Created by Salman on 07/05/18.
//  Copyright © 2018 Salman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
        
        // Do any additional setup after loading the view, typically from a ni
//        ApplicationPreference.saveUserId(userId: <#T##String#>)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

