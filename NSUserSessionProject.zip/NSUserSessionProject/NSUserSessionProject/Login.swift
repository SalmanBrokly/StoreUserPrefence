//
//  Login.swift
//  NSUserSessionProject
//
//  Created by Salman on 07/05/18.
//  Copyright © 2018 Salman. All rights reserved.
//

import UIKit

class Login: UIViewController {

    @IBOutlet weak var tv_userID: UITextField!
    @IBOutlet weak var tv_name: UITextField!
    @IBOutlet weak var btn_Save: UIButton!
    @IBOutlet weak var btn_Show: UIButton!
    @IBOutlet weak var lbl_userId: UILabel!
    @IBOutlet weak var btn_clearData: UIButton!
     var strUserId = String()
     var strUserName = String()
    
    
    @IBAction func btn_Save(_ sender: UIButton) {
        
  strUserId =  tv_userID.text!
         strUserName =  tv_name.text!
        
         ApplicationPreference.saveUserId(userId: strUserId)
        ApplicationPreference.saveUserName(userName: strUserName)
        
    }
    
    
    
    @IBAction func btn_Show(_ sender :UIButton){
    
   lbl_userId.text = ApplicationPreference.getUserId()
    }
    
    @IBAction func btn_clearData(_ sender : UIButton){
    
//    ApplicationPreference.clearAllData()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
