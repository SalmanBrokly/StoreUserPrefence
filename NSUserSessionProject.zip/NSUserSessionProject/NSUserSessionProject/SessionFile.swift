//
//  File.swift
//  NSUserSessionProject
//
//  Created by Salman on 07/05/18.
//  Copyright © 2018 Salman. All rights reserved.
//

import Foundation

class MySession {
    var SaveManagerKeys = String.self
    

    
    //MARK Singleton
    private static let instance = MySession()
    
    class func sharedInstance() -> MySession {
        return instance
    }
    
    

    
    
       // MARK: Helpers
    func standard() -> UserDefaults {
    return UserDefaults.standard
    }

    func sync()  {
        standard().synchronize()
    }
}

