//
//  AppConstant.swift
//  NSUserSessionProject
//
//  Created by Salman on 07/05/18.
//  Copyright © 2018 Salman. All rights reserved.
//

import Foundation

class AppConstant{
    
     static let userDefaultAppTokenKey: String = "userDefaultAppTokenKey"
     static let userDefaultUserNameKey: String = "userDefaultUserNameKey"
     static let userDefaultUserIdKey: String = "userDefaultUserIdKey"
     static let userDefaultUserLoginInfoKey: String = "userDefaultUserLoginInfoKey"
//     static let userDefaultAppTokenKey: String = "userDefaultAppTokenKey"
}
